#!/usr/bin/env python3
"""
Interface Linux Desktop 0.0.2.8
Inicia o servidor local, espera /api/health e abre a interface no navegador
PADRÃO do sistema usando apenas a biblioteca nativa webbrowser.

Variáveis úteis:
  PORT=3000                 porta do servidor
  INTERFACE_AUTO_OPEN=0    não abre o navegador
  INTERFACE_URL=...         URL alternativa (somente http://127.0.0.1/localhost)
"""
import os
import signal
import subprocess
import sys
import time
import urllib.error
import urllib.request
import webbrowser

HOST = "127.0.0.1"
PORT = int(os.environ.get("PORT", "3000"))
URL = os.environ.get("INTERFACE_URL", f"http://{HOST}:{PORT}")
AUTO_OPEN = os.environ.get("INTERFACE_AUTO_OPEN", "1").lower() not in {"0", "false", "no", "off"}
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
NODE = os.environ.get("NODE_BIN", "node")
SERVER = os.path.join(ROOT, "server.js")

def valid_url(url: str) -> bool:
    return url.startswith(("http://127.0.0.1:", "http://localhost:"))

def wait_for_server(url: str, timeout: float = 20.0) -> bool:
    deadline = time.monotonic() + timeout
    health = url.rstrip("/") + "/api/health"
    while time.monotonic() < deadline:
        try:
            with urllib.request.urlopen(health, timeout=1.0) as response:
                if response.status == 200:
                    return True
        except (urllib.error.URLError, TimeoutError, OSError):
            pass
        time.sleep(0.2)
    return False

def open_default_browser(url: str) -> bool:
    # webbrowser usa o navegador padrão configurado no Linux.
    # Não há caminho fixo para Chrome/Firefox e nenhuma dependência externa.
    return bool(webbrowser.open_new_tab(url))

def main() -> int:
    if not valid_url(URL):
        print(f"[Interface] URL recusada por segurança: {URL}", file=sys.stderr)
        return 2
    if not os.path.exists(SERVER):
        print(f"[Interface] server.js não encontrado: {SERVER}", file=sys.stderr)
        return 2

    env = os.environ.copy()
    env["NODE_ENV"] = env.get("NODE_ENV", "production")
    env["PORT"] = str(PORT)

    print(f"[Interface] iniciando servidor em {URL}", flush=True)
    try:
        proc = subprocess.Popen([NODE, SERVER], cwd=ROOT, env=env)
    except OSError as exc:
        print(f"[Interface] não foi possível iniciar Node.js: {exc}", file=sys.stderr)
        return 1

    def stop(_sig=None, _frame=None):
        if proc.poll() is None:
            proc.terminate()
            try:
                proc.wait(timeout=3)
            except subprocess.TimeoutExpired:
                proc.kill()
        raise SystemExit(0)

    signal.signal(signal.SIGINT, stop)
    signal.signal(signal.SIGTERM, stop)

    if not wait_for_server(URL):
        code = proc.poll()
        if code is None:
            print("[Interface] servidor não respondeu a /api/health em 20 s.", file=sys.stderr)
            stop()
        print(f"[Interface] servidor terminou antes de ficar pronto (código {code}).", file=sys.stderr)
        return code or 1

    print(f"[Interface] servidor pronto: {URL}", flush=True)
    if AUTO_OPEN:
        if open_default_browser(URL):
            print("[Interface] navegador padrão aberto automaticamente.", flush=True)
        else:
            print(f"[Interface] não foi possível abrir o navegador automaticamente. Abra: {URL}", file=sys.stderr)
    else:
        print("[Interface] abertura automática do navegador desativada (INTERFACE_AUTO_OPEN=0).", flush=True)

    try:
        return proc.wait()
    except KeyboardInterrupt:
        stop()

if __name__ == "__main__":
    raise SystemExit(main())
