/* Preferências persistentes (0.0.2.7) — store único usado por main.jsx, SystemSettings.jsx, FileManager.jsx e Tray.jsx.
   Fonte da verdade: o servidor (~/.config/interface-linux-desktop/settings.json, via /api/settings).
   - patchSettings() aplica a mudança NA HORA na tela (otimista) e envia ao servidor com atraso curto (agrupa várias mudanças).
   - O último estado também fica no localStorage só como cache de primeira pintura (evita o "piscar" de tema ao abrir).
   - Na primeira vez em que o servidor ainda não tem arquivo, migra o que a 0.0.2.6 e anteriores guardavam no navegador (ui.dark, ui.wallpaper, ui.dockapps). */
import {useSyncExternalStore} from 'react';
import {api, post} from './utils';

export const DEFAULTS = {
  appearance: {theme: 'dark', wallpaper: 'padrao', customWallpaper: null},
  interface: {animations: true, dynamicDock: true, notifications: true, desktopIcons: true, visualEffects: true, fileManager: 'native'},
  windows: {rememberGeometry: true, restoreOpen: false, geometry: {}, open: []},
  files: {lastPath: null, showHidden: false},
  dock: {apps: []},
};
const GROUPS = Object.keys(DEFAULTS), CACHE_KEY = 'ui.settings.cache.v1', SAVE_DELAY = 350;
const isObj = v => v && typeof v === 'object' && !Array.isArray(v);
const clone = v => JSON.parse(JSON.stringify(v));
const lsGet = k => { try { return JSON.parse(localStorage.getItem(k)); } catch { return null; } };
const validDock = v => (Array.isArray(v) ? v : []).filter(x => x && ['desktop', 'flatpak', 'snap'].includes(x.kind) && typeof x.id === 'string' && /^[\w.+@-]{1,160}$/.test(x.id) && typeof x.name === 'string')
  .slice(-12).map(({kind, id, name}) => ({kind, id, name: name.slice(0, 80)}));

/* Mesma regra do servidor (server/settings.js applyPatch), sem a validação: o servidor devolve a versão final saneada. */
export function merge(base, patch) {
  const next = clone(base);
  for (const g of GROUPS) {
    if (!isObj(patch?.[g])) continue;
    for (const [k, v] of Object.entries(patch[g])) {
      if (g === 'windows' && k === 'geometry' && isObj(v)) { for (const [id, gm] of Object.entries(v)) { if (gm === null) delete next.windows.geometry[id]; else next.windows.geometry[id] = gm; } }
      else next[g][k] = v;
    }
  }
  if (next.appearance.wallpaper === 'custom' && !next.appearance.customWallpaper) next.appearance.wallpaper = 'padrao';
  return next;
}
/* Junta dois patches pendentes (o segundo vence); geometria por janela, inclusive os null (remoções). */
function combine(a, b) {
  const r = clone(a || {});
  for (const g of GROUPS) {
    if (!isObj(b?.[g])) continue;
    r[g] = r[g] || {};
    for (const [k, v] of Object.entries(b[g])) r[g][k] = g === 'windows' && k === 'geometry' && isObj(v) ? {...(r[g][k] || {}), ...v} : v;
  }
  return r;
}

function initial() {
  const s = clone(DEFAULTS), cached = lsGet(CACHE_KEY);
  if (isObj(cached)) { for (const g of GROUPS) if (isObj(cached[g])) Object.assign(s[g], cached[g]); return s; }
  const dark = lsGet('ui.dark'), wp = lsGet('ui.wallpaper'), dock = lsGet('ui.dockapps'); /* primeiro uso após atualizar da 0.0.2.6 */
  if (dark === false) s.appearance.theme = 'light';
  if (typeof wp === 'string' && wp !== 'custom' && /^[a-z0-9-]{1,40}$/.test(wp)) s.appearance.wallpaper = wp;
  s.dock.apps = validDock(dock);
  return s;
}
function legacyPatch() {
  const dark = lsGet('ui.dark'), wp = lsGet('ui.wallpaper'), dock = lsGet('ui.dockapps'), p = {};
  if (typeof dark === 'boolean' || (typeof wp === 'string' && wp !== 'custom')) p.appearance = {...(typeof dark === 'boolean' ? {theme: dark ? 'dark' : 'light'} : {}), ...(typeof wp === 'string' && wp !== 'custom' ? {wallpaper: wp} : {})};
  if (Array.isArray(dock) && dock.length) p.dock = {apps: validDock(dock)};
  return Object.keys(p).length ? p : null;
}

let state = {ready: false, settings: initial(), meta: null, saveError: null};
const subs = new Set();
const set = p => {
  state = {...state, ...p};
  try { localStorage.setItem(CACHE_KEY, JSON.stringify(state.settings)); } catch { /* modo privado / quota */ }
  subs.forEach(f => f());
};
export const subscribe = f => (subs.add(f), () => subs.delete(f));
export const getState = () => state;
export const getSettings = () => state.settings;
export const useSettings = () => useSyncExternalStore(subscribe, getState);

let pending = null, timer = null, sending = false;
async function flush({keepalive = false} = {}) {
  clearTimeout(timer); timer = null;
  if (!pending) return;
  if (sending && !keepalive) { timer = setTimeout(flush, 200); return; } /* uma requisição por vez: mantém a ordem das mudanças */
  const body = pending; pending = null; sending = true;
  try {
    const d = await api('/api/settings', {method: 'PATCH', headers: {'content-type': 'application/json'}, body: JSON.stringify(body), keepalive});
    set(pending ? {saveError: null} : {settings: d.settings, saveError: null}); /* se já há mudança nova pendente, não sobrescreve a tela com o estado antigo do servidor */
  } catch (e) {
    pending = combine(body, pending); set({saveError: e.message || 'Não foi possível salvar as preferências.'});
    timer ||= setTimeout(flush, 5000); /* tenta de novo */
  } finally { sending = false; }
}
export function patchSettings(patch) {
  set({settings: merge(state.settings, patch)});
  pending = combine(pending, patch);
  clearTimeout(timer); timer = setTimeout(flush, SAVE_DELAY);
}
export const flushSettings = () => flush();

/* Carrega do servidor (e migra o que estava no navegador, se for a primeira vez). */
export async function loadSettings() {
  try {
    const d = await api('/api/settings');
    let settings = d.settings;
    if (!d.meta?.exists) {
      const mig = legacyPatch();
      if (mig) { settings = merge(settings, mig); pending = combine(pending, mig); timer ||= setTimeout(flush, 0); ['ui.dark', 'ui.wallpaper', 'ui.dockapps'].forEach(k => { try { localStorage.removeItem(k); } catch {} }); }
    }
    if (pending) settings = merge(settings, pending);
    set({ready: true, settings, meta: d.meta, saveError: null});
  } catch (e) { set({ready: true, saveError: `Não foi possível carregar as preferências: ${e.message}`}); } /* segue com o cache local */
}
/* Usado após o upload do papel de parede: o servidor já devolve o estado final. */
export const adoptSettings = settings => set({settings: pending ? merge(settings, pending) : settings});
export async function resetSettings() {
  pending = null; clearTimeout(timer); timer = null;
  const d = await post('/api/settings/reset', {});
  set({settings: d.settings, saveError: null});
}

/* Não perde a última mudança se a aba/janela fechar antes do atraso de envio. */
if (typeof window !== 'undefined') {
  window.addEventListener('pagehide', () => flush({keepalive: true}));
  document.addEventListener('visibilitychange', () => { if (document.hidden) flush({keepalive: true}); });
}
