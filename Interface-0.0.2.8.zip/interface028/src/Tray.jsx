import {useCallback, useEffect, useRef, useState} from 'react';
import {createPortal} from 'react-dom';
import {Wifi, WifiOff, Cable, Bluetooth, BluetoothOff, Volume1, Volume2, VolumeX, Battery, BatteryLow, BatteryMedium, BatteryFull, BatteryCharging,
  Moon, Sun, Lock, Power, RotateCw, LogOut, Pause, ChevronRight, Settings as SettingsIcon, Rocket, Scale, Leaf, Check, AlertCircle} from 'lucide-react';
import {api, post} from './utils';

/* Barra de menus e bandeja do sistema (0.0.2.7). O servidor (server/tray.js) lê o estado; as mudanças reutilizam as rotas /api/sys/*. */

/* O popover vai para dentro de .desktop (portal) para herdar o tema claro/escuro e ficar fora dos estilos de ".menubar button". */
function Pop({anchor, align = 'left', onClose, className = '', children}) {
  const root = anchor.current?.closest('.desktop');
  useEffect(() => {
    const k = e => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', k); return () => window.removeEventListener('keydown', k);
  }, [onClose]);
  if (!root) return null;
  const r = anchor.current.getBoundingClientRect(), dr = root.getBoundingClientRect();
  const pos = align === 'right' ? {right: Math.max(8, dr.right - r.right)} : {left: Math.max(8, Math.min(r.left - dr.left, dr.width - 260))};
  return createPortal(<>
    <div className="pop-backdrop" onMouseDown={onClose}/>
    <div className={`pop ${className}`} style={pos} role="menu">{children}</div>
  </>, root);
}

/* Menu suspenso da barra. items: {label, onClick, kbd, checked, disabled, danger} ou {separator: true}. */
export function MenuDropdown({label, items, open, onToggle, onClose, strong = false, title}) {
  const ref = useRef(null);
  return (
    <>
      <button ref={ref} className={`menu-trig${strong ? ' strong' : ''}${open ? ' open' : ''}`} aria-haspopup="menu" aria-expanded={open} title={title} onClick={onToggle}>{label}</button>
      {open && <Pop anchor={ref} onClose={onClose} className="menu-list">
        {items.map((it, i) => it.separator ? <i key={i} role="separator"/> : (
          <button key={i} role="menuitem" className={it.danger ? 'danger' : ''} disabled={it.disabled} onClick={() => { onClose(); it.onClick?.(); }}>
            <span className="chk">{it.checked ? <Check size={13}/> : null}</span><span className="lbl">{it.label}</span>{it.kbd && <kbd>{it.kbd}</kbd>}
          </button>))}
      </Pop>}
    </>
  );
}

/* Diálogo de confirmação (energia/sessão). */
export function ConfirmDialog({title, body, confirmLabel, danger, busy, onCancel, onConfirm}) {
  useEffect(() => { const k = e => { if (e.key === 'Escape') onCancel(); }; window.addEventListener('keydown', k); return () => window.removeEventListener('keydown', k); }, [onCancel]);
  return (
    <div className="confirm-back" onMouseDown={e => { if (e.target === e.currentTarget) onCancel(); }}>
      <div className="confirm" role="alertdialog" aria-modal="true" aria-label={title}>
        <h3>{title}</h3><p>{body}</p>
        <div className="confirm-btns"><button autoFocus onClick={onCancel}>Cancelar</button><button className={danger ? 'danger' : 'primary'} disabled={busy} onClick={onConfirm}>{busy ? 'Aguarde…' : confirmLabel}</button></div>
      </div>
    </div>
  );
}

/* ---------- Estado da bandeja (consulta o servidor; mais rápido enquanto o painel está aberto) ---------- */
export function useTrayStatus(active) {
  const [st, setSt] = useState(null);
  const alive = useRef(true), activeRef = useRef(active); activeRef.current = active;
  const refresh = useCallback(() => api('/api/tray/status').then(d => alive.current && setSt(d)).catch(() => alive.current && setSt(s => ({...(s || {}), offline: true}))), []);
  useEffect(() => {
    alive.current = true; let t;
    const tick = async () => { if (!document.hidden) await refresh(); if (alive.current) t = setTimeout(tick, activeRef.current ? 3000 : 12000); };
    tick(); return () => { alive.current = false; clearTimeout(t); };
  }, [refresh]);
  useEffect(() => { if (active) refresh(); }, [active, refresh]);
  return [st, setSt, refresh];
}

const volIcon = v => !v?.available || v.mute || v.volume === 0 ? VolumeX : v.volume < 50 ? Volume1 : Volume2;
const batIcon = b => b.status === 'charging' ? BatteryCharging : b.percent == null ? Battery : b.percent < 15 ? BatteryLow : b.percent < 50 ? BatteryMedium : BatteryFull;
const netIcon = n => n.type === 'ethernet' ? Cable : n.state === 'connected' ? Wifi : WifiOff;

/* Ícones da barra: rede, Bluetooth (se ligado), volume e bateria. Clique abre o painel; rolar sobre ele muda o volume. */
export function TrayButton({status, open, onToggle, onWheelVolume, btnRef}) {
  const n = status?.network, v = status?.volume, b = status?.battery, bt = status?.bluetooth;
  const NI = n?.available ? netIcon(n) : null, VI = volIcon(v), BI = b?.present ? batIcon(b) : null;
  const tip = [n?.available && (n.state === 'connected' ? `Rede: ${n.name || n.type}${n.signal != null ? ` (${n.signal}%)` : ''}` : 'Sem rede'),
    v?.available && `Volume: ${v.mute ? 'mudo' : v.volume + '%'}`, b?.present && `Bateria: ${b.percent ?? '?'}%`].filter(Boolean).join(' · ') || 'Painel do sistema';
  return (
    <button ref={btnRef} className={`tray${open ? ' open' : ''}`} aria-haspopup="dialog" aria-expanded={open} aria-label="Painel do sistema" title={tip}
      onClick={onToggle} onWheel={e => v?.available && onWheelVolume(e.deltaY < 0 ? 5 : -5)}>
      {NI && <NI size={15}/>}
      {bt?.available && bt.powered && <Bluetooth size={14}/>}
      {v?.available && <VI size={15}/>}
      {BI && <span className="bat"><BI size={16}/><small>{b.percent ?? ''}{b.percent != null ? '%' : ''}</small></span>}
      {!status && <Wifi size={15} style={{opacity: .4}}/>}
    </button>
  );
}

/* ---------- Painel rápido ---------- */
const PROFILES = [{id: 'performance', label: 'Desempenho', icon: Rocket}, {id: 'balanced', label: 'Equilibrado', icon: Scale}, {id: 'power-saver', label: 'Economia', icon: Leaf}];

function Tile({icon: I, title, sub, on, disabled, onClick, onMore, moreLabel}) {
  return (
    <div className={`qp-tile${on ? ' on' : ''}${disabled ? ' off' : ''}`}>
      <button className="qp-tile-main" disabled={disabled} aria-pressed={!!on} onClick={onClick}><I size={18}/><span><b>{title}</b><small>{sub}</small></span></button>
      {onMore && <button className="qp-tile-more" aria-label={moreLabel} title={moreLabel} onClick={onMore}><ChevronRight size={16}/></button>}
    </div>
  );
}

export function QuickPanel({anchor, status, setStatus, refresh, dark, setDark, notify, openSettings, launchSystem, askPower, onClose}) {
  const n = status?.network || {}, v = status?.volume || {}, bt = status?.bluetooth || {}, p = status?.profile || {}, b = status?.battery || {};
  const [vol, setVol] = useState(v.volume ?? 0);
  const drag = useRef(false), t = useRef(null), release = useRef(null);
  useEffect(() => { if (!drag.current && v.volume != null) setVol(v.volume); }, [v.volume]);
  useEffect(() => () => { clearTimeout(t.current); clearTimeout(release.current); }, []);

  const fail = (title, e) => notify({title, body: e.message || String(e)});
  const later = () => setTimeout(refresh, 900);
  const toggleWifi = async () => { const on = !n.wifiEnabled; setStatus(s => ({...s, network: {...s.network, wifiEnabled: on, ...(on ? {} : {state: 'disconnected', type: null, name: null})}}));
    try { await post('/api/sys/wifi/power', {on}); } catch (e) { fail('Wi-Fi', e); } later(); };
  const toggleBt = async () => { const on = !bt.powered; setStatus(s => ({...s, bluetooth: {...s.bluetooth, powered: on}}));
    try { await post('/api/sys/bluetooth/power', {on}); } catch (e) { fail('Bluetooth', e); } later(); };
  const sendVolume = value => post('/api/sys/sound/volume', {value}).catch(e => fail('Volume', e));
  const onSlide = e => {
    const value = Number(e.target.value); drag.current = true; setVol(value);
    setStatus(s => ({...s, volume: {...s.volume, volume: value, mute: false}}));
    clearTimeout(t.current); t.current = setTimeout(() => sendVolume(value), 120);
    clearTimeout(release.current); release.current = setTimeout(() => { drag.current = false; refresh(); }, 700);
  };
  const toggleMute = async () => { setStatus(s => ({...s, volume: {...s.volume, mute: !s.volume.mute}})); try { await post('/api/sys/sound/mute', {kind: 'output'}); } catch (e) { fail('Som', e); } later(); };
  const setProfile = async id => { setStatus(s => ({...s, profile: {...s.profile, current: id}})); try { await post('/api/sys/energy/profile', {profile: id}); } catch (e) { fail('Energia', e); } later(); };
  const go = (tab) => { onClose(); openSettings(tab); };
  const VI = volIcon({...v, volume: vol});
  const netSub = !n.available ? 'Indisponível' : n.state === 'connected' ? (n.name || (n.type === 'ethernet' ? 'Cabeada' : 'Conectado')) + (n.signal != null ? ` · ${n.signal}%` : '') : n.wifiEnabled === false ? 'Desligado' : n.state === 'connecting' ? 'Conectando…' : 'Sem conexão';

  return (
    <Pop anchor={anchor} align="right" onClose={onClose} className="qp">
      {!status ? <p className="qp-note">Carregando…</p> : <>
        {status.offline && <p className="qp-note err"><AlertCircle size={13}/> Sem resposta do servidor.</p>}
        <div className="qp-grid">
          <Tile icon={n.type === 'ethernet' ? Cable : n.wifiEnabled === false ? WifiOff : Wifi} title={n.type === 'ethernet' ? 'Rede' : 'Wi-Fi'} sub={netSub} on={n.state === 'connected'}
            disabled={!n.available || (n.wifiEnabled == null) } onClick={toggleWifi} onMore={() => go('wifi')} moreLabel="Redes Wi-Fi"/>
          <Tile icon={bt.powered ? Bluetooth : BluetoothOff} title="Bluetooth" sub={!bt.available ? 'Indisponível' : bt.powered ? 'Ligado' : 'Desligado'} on={bt.powered}
            disabled={!bt.available} onClick={toggleBt} onMore={() => go('bluetooth')} moreLabel="Dispositivos Bluetooth"/>
        </div>
        {v.available && (
          <div className="qp-slider">
            <button aria-label={v.mute ? 'Ativar o som' : 'Silenciar'} title={v.mute ? 'Ativar o som' : 'Silenciar'} onClick={toggleMute}><VI size={18}/></button>
            <input type="range" min="0" max="100" step="1" value={Math.min(100, vol)} aria-label="Volume" onChange={onSlide} onPointerUp={() => { clearTimeout(release.current); release.current = setTimeout(() => { drag.current = false; refresh(); }, 300); }}/>
            <output>{v.mute ? 'mudo' : `${vol}%`}</output>
            <button aria-label="Configurações de som" title="Configurações de som" className="qp-more" onClick={() => go('sound')}><ChevronRight size={16}/></button>
          </div>)}
        {p.available && (
          <div className="qp-seg" role="group" aria-label="Perfil de energia">
            {PROFILES.map(({id, label, icon: I}) => <button key={id} className={p.current === id ? 'on' : ''} aria-pressed={p.current === id} onClick={() => setProfile(id)}><I size={15}/><span>{label}</span></button>)}
          </div>)}
        <div className="qp-grid">
          <Tile icon={dark ? Moon : Sun} title="Tema escuro" sub={dark ? 'Ativado' : 'Desativado'} on={dark} onClick={() => setDark(!dark)}/>
          <Tile icon={SettingsIcon} title="Configurações" sub="Sistema (GNOME)" onClick={() => { onClose(); launchSystem('settings'); }}/>
        </div>
        {b.present && <p className="qp-note">{b.status === 'charging' ? 'Carregando' : b.status === 'full' ? 'Carga completa' : 'Na bateria'} · {b.percent ?? '?'}%</p>}
        <div className="qp-power" role="group" aria-label="Sessão">
          <button onClick={() => { onClose(); askPower('lock'); }} title="Bloquear a tela"><Lock size={16}/><span>Bloquear</span></button>
          <button onClick={() => { onClose(); askPower('suspend'); }} disabled={status.power?.enabled === false} title="Suspender"><Pause size={16}/><span>Suspender</span></button>
          <button onClick={() => { onClose(); askPower('reboot'); }} disabled={status.power?.enabled === false} title="Reiniciar"><RotateCw size={16}/><span>Reiniciar</span></button>
          <button className="danger" onClick={() => { onClose(); askPower('poweroff'); }} disabled={status.power?.enabled === false} title="Desligar"><Power size={16}/><span>Desligar</span></button>
          <button onClick={() => { onClose(); askPower('logout'); }} disabled={status.power?.enabled === false} title="Encerrar a sessão"><LogOut size={16}/><span>Sair</span></button>
        </div>
        {status.power?.enabled === false && <p className="qp-note">Ações de energia desativadas neste servidor.</p>}
      </>}
    </Pop>
  );
}

export const POWER_TEXT = {
  lock: {title: 'Bloquear a tela', body: 'A sessão será bloqueada.', label: 'Bloquear'},
  suspend: {title: 'Suspender', body: 'O computador será suspenso agora. Salve seu trabalho.', label: 'Suspender'},
  reboot: {title: 'Reiniciar', body: 'O computador será reiniciado agora. Programas abertos e trabalho não salvo podem ser perdidos.', label: 'Reiniciar', danger: true},
  poweroff: {title: 'Desligar', body: 'O computador será desligado agora. Programas abertos e trabalho não salvo podem ser perdidos.', label: 'Desligar', danger: true},
  logout: {title: 'Encerrar sessão', body: 'Você sairá da sessão atual. Programas abertos serão fechados.', label: 'Sair', danger: true},
};
