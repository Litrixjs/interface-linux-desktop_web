/* Gestor de arquivos da Interface (0.0.2.7) — rotas /api/files/*.
   Roda como o seu usuário: o sistema operacional continua decidindo o que pode ou não ser lido/gravado.
   Proteções extras: caminhos precisam ser absolutos (ou "~"), nomes não podem conter "/" nem "\0",
   a raiz, a home e as pastas de sistema (/etc, /usr, …) não podem ser renomeadas, movidas nem apagadas,
   "apagar" = mover para a Lixeira (gio trash, recuperável) e copiar/mover nunca sobrescreve (cria "nome (cópia)"). */
import path from 'node:path';
import fs from 'node:fs/promises';
import fsSync from 'node:fs';
import {sh} from './system.js';
import {startDetached} from './browser.js';

const MAX_ENTRIES = 5000, MAX_BATCH = 200;
const SYSTEM_TOP = new Set(['bin', 'boot', 'dev', 'etc', 'home', 'lib', 'lib32', 'lib64', 'libx32', 'proc', 'root', 'run', 'sbin', 'snap', 'srv', 'sys', 'usr', 'var', 'opt', 'mnt', 'media']);

const fail = (status, error, message) => Object.assign(new Error(message), {status, code: error, expose: true});
const ERRORS = {
  ENOENT: [404, 'Arquivo ou pasta não encontrado.'], ENOTDIR: [400, 'O caminho não é uma pasta.'], EACCES: [403, 'Sem permissão para esta operação.'],
  EPERM: [403, 'Operação não permitida.'], EEXIST: [409, 'Já existe um item com esse nome.'], ENOTEMPTY: [409, 'A pasta não está vazia.'],
  EISDIR: [400, 'O destino é uma pasta.'], ENOSPC: [507, 'Sem espaço em disco.'], EROFS: [403, 'Sistema de arquivos somente leitura.'],
  ENAMETOOLONG: [400, 'Nome longo demais.'], EINVAL: [400, 'Operação inválida.'], ELOOP: [400, 'Links simbólicos em excesso.'],
};
export function describe(e) {
  if (e?.expose) return {status: e.status, error: e.code, message: e.message};
  const [status, message] = ERRORS[e?.code] || [500, e?.message || 'Erro inesperado.'];
  return {status, error: e?.code || 'error', message};
}

export const cleanName = n => {
  const s = String(n ?? '').trim();
  return !s || s === '.' || s === '..' || /[/\0]/.test(s) || Buffer.byteLength(s) > 255 ? null : s;
};
export function resolveUser(p, home) {
  const s = String(p ?? '');
  if (!s || s.length > 4096 || s.includes('\0') || !(s[0] === '/' || s === '~' || s.startsWith('~/'))) return null;
  return path.resolve(s === '~' || s.startsWith('~/') ? path.join(home, s.slice(1)) : s);
}
export const isProtected = (p, home) => p === '/' || p === home || (path.dirname(p) === '/' && SYSTEM_TOP.has(path.basename(p)));

const exists = p => fs.lstat(p).then(() => true, () => false);
/* "nome.txt" → "nome (cópia).txt" → "nome (cópia 2).txt" … */
export async function uniqueTarget(dir, name) {
  const first = path.join(dir, name); if (!(await exists(first))) return first;
  const ext = path.extname(name), base = ext ? name.slice(0, -ext.length) : name;
  for (let n = 1; n < 1000; n++) { const t = path.join(dir, `${base} (cópia${n > 1 ? ' ' + n : ''})${ext}`); if (!(await exists(t))) return t; }
  throw fail(409, 'EEXIST', 'Não foi possível criar um nome livre para a cópia.');
}
async function moveItem(src, target) {
  try { await fs.rename(src, target); }
  catch (e) {
    if (e.code !== 'EXDEV') throw e; /* outro disco/partição: copia e remove a origem */
    await fs.cp(src, target, {recursive: true, errorOnExist: true, force: false, verbatimSymlinks: true});
    await fs.rm(src, {recursive: true, force: true});
  }
}

/* Pastas padrão do usuário (XDG): respeita o idioma do sistema (Documentos, Transferências…) lendo ~/.config/user-dirs.dirs. */
export function xdgDirs(home) {
  const out = {};
  try {
    for (const l of fsSync.readFileSync(path.join(home, '.config', 'user-dirs.dirs'), 'utf8').split('\n')) {
      const m = l.match(/^XDG_(\w+)_DIR="(.*)"\s*$/); if (m) out[m[1]] = m[2].replace(/^\$HOME/, home);
    }
  } catch {}
  return out;
}
const isDir = p => { try { return fsSync.statSync(p).isDirectory(); } catch { return false; } };
export function places(home, user = process.env.USER || '') {
  const x = xdgDirs(home), list = [{id: 'home', label: 'Pasta pessoal', path: home}];
  for (const [id, label, key, fallback] of [['desktop', 'Área de trabalho', 'DESKTOP', 'Desktop'], ['documents', 'Documentos', 'DOCUMENTS', 'Documents'],
    ['downloads', 'Downloads', 'DOWNLOAD', 'Downloads'], ['music', 'Músicas', 'MUSIC', 'Music'], ['pictures', 'Imagens', 'PICTURES', 'Pictures'], ['videos', 'Vídeos', 'VIDEOS', 'Videos']]) {
    const p = x[key] || path.join(home, fallback); if (p !== home && isDir(p)) list.push({id, label, path: p});
  }
  const trash = path.join(home, '.local', 'share', 'Trash', 'files'); if (isDir(trash)) list.push({id: 'trash', label: 'Lixeira', path: trash});
  for (const base of [`/media/${user}`, `/run/media/${user}`]) {
    try { for (const n of fsSync.readdirSync(base)) if (!n.startsWith('.') && isDir(path.join(base, n))) list.push({id: `media:${n}`, label: n, path: path.join(base, n)}); } catch {}
  }
  list.push({id: 'root', label: 'Sistema de arquivos', path: '/'});
  return list;
}

export function registerFileRoutes(app, {home, findBin = () => null}) {
  const wrap = fn => async (req, res) => { try { await fn(req, res); } catch (e) { const d = describe(e); res.status(d.status).json({error: d.error, message: d.message}); } };
  const need = (p, what = 'Caminho') => { const r = resolveUser(p, home); if (!r) throw fail(400, 'bad_path', `${what} inválido.`); return r; };
  const mutable = p => { if (isProtected(p, home)) throw fail(403, 'protected', 'Esta pasta é protegida e não pode ser alterada pela Interface.'); return p; };
  const asDir = async p => { const st = await fs.stat(p); if (!st.isDirectory()) throw fail(400, 'not_a_directory', 'O destino não é uma pasta.'); return p; };
  const paths = body => {
    if (!Array.isArray(body?.paths) || !body.paths.length) throw fail(400, 'bad_request', 'Informe {paths: [...]}.');
    if (body.paths.length > MAX_BATCH) throw fail(400, 'too_many', `No máximo ${MAX_BATCH} itens por vez.`);
    return body.paths;
  };
  const inDir = async body => { const dir = await asDir(need(body?.dir, 'Pasta')), name = cleanName(body?.name); if (!name) throw fail(400, 'bad_name', 'Nome inválido (não use "/" e não deixe vazio).'); return path.join(dir, name); };

  app.get('/api/files/places', wrap(async (_req, res) => res.json({home, places: places(home)})));

  app.get('/api/files/list', wrap(async (req, res) => {
    const p = need(req.query.path || '~'), showHidden = req.query.hidden === '1';
    await asDir(p);
    const all = (await fs.readdir(p, {withFileTypes: true})).filter(d => showHidden || !d.name.startsWith('.'));
    const part = all.slice(0, MAX_ENTRIES), entries = [];
    for (let i = 0; i < part.length; i += 256) {
      entries.push(...await Promise.all(part.slice(i, i + 256).map(async d => {
        const s = await fs.stat(path.join(p, d.name)).catch(() => null); /* stat segue links: pastas via link continuam navegáveis */
        const dir = s ? s.isDirectory() : d.isDirectory();
        return {name: d.name, type: dir ? 'dir' : 'file', size: dir ? 0 : (s?.size ?? 0), mtime: s?.mtimeMs ?? 0, ext: dir ? '' : path.extname(d.name).toLowerCase(),
          hidden: d.name.startsWith('.'), link: d.isSymbolicLink(), broken: !s};
      })));
    }
    entries.sort((a, b) => (a.type === b.type ? 0 : a.type === 'dir' ? -1 : 1) || a.name.localeCompare(b.name, 'pt-BR', {numeric: true, sensitivity: 'base'}));
    res.json({path: p, parent: p === '/' ? null : path.dirname(p), entries, total: all.length, truncated: all.length > MAX_ENTRIES});
  }));

  app.post('/api/files/mkdir', wrap(async (req, res) => { const t = await inDir(req.body); await fs.mkdir(t); res.json({ok: true, path: t}); }));
  app.post('/api/files/create', wrap(async (req, res) => { const t = await inDir(req.body); await fs.writeFile(t, '', {flag: 'wx'}); res.json({ok: true, path: t}); }));

  app.post('/api/files/rename', wrap(async (req, res) => {
    const src = mutable(need(req.body?.path)), name = cleanName(req.body?.name);
    if (!name) throw fail(400, 'bad_name', 'Nome inválido (não use "/" e não deixe vazio).');
    await fs.lstat(src);
    const target = path.join(path.dirname(src), name);
    if (target === src) return res.json({ok: true, path: src});
    if (await exists(target)) throw fail(409, 'EEXIST', 'Já existe um item com esse nome.'); /* fs.rename sobrescreveria em silêncio */
    await fs.rename(src, target); res.json({ok: true, path: target});
  }));

  /* "Excluir" = Lixeira do usuário (recuperável). Não existe exclusão permanente por esta rota. */
  app.post('/api/files/trash', wrap(async (req, res) => {
    const results = [];
    for (const raw of paths(req.body)) {
      const r = {path: raw};
      try {
        const p = mutable(need(raw)); await fs.lstat(p);
        const o = await sh('gio', ['trash', '--', p]);
        if (o.missing) throw fail(501, 'not_installed', 'Para mover à Lixeira instale: sudo apt install libglib2.0-bin (ou rode ./setup-environment.sh).');
        if (!o.ok) throw fail(500, 'trash_failed', (o.stderr.trim().split('\n')[0] || 'Falha ao mover para a Lixeira.').replace(/^gio:\s*/, ''));
        r.ok = true;
      } catch (e) { r.ok = false; r.error = describe(e).message; if (e.status === 501) return res.status(501).json({error: 'not_installed', message: e.message}); }
      results.push(r);
    }
    res.json({ok: results.every(r => r.ok), results});
  }));

  app.post('/api/files/paste', wrap(async (req, res) => {
    const move = req.body?.mode === 'move';
    if (!move && req.body?.mode !== 'copy') throw fail(400, 'bad_request', 'mode deve ser "copy" ou "move".');
    const dest = await asDir(need(req.body?.dest, 'Pasta de destino')), results = [];
    for (const raw of paths(req.body)) {
      const r = {path: raw};
      try {
        const src = need(raw), st = await fs.lstat(src);
        if (move) mutable(src);
        if (st.isDirectory() && (dest === src || dest.startsWith(src + path.sep))) throw fail(400, 'into_itself', 'Não é possível colocar uma pasta dentro dela mesma.');
        if (move && path.dirname(src) === dest) { r.ok = true; r.to = src; results.push(r); continue; }
        const target = await uniqueTarget(dest, path.basename(src));
        if (move) await moveItem(src, target);
        else await fs.cp(src, target, {recursive: true, errorOnExist: true, force: false, verbatimSymlinks: true});
        r.ok = true; r.to = target;
      } catch (e) { r.ok = false; r.error = describe(e).message; }
      results.push(r);
    }
    res.json({ok: results.every(r => r.ok), results});
  }));

  /* Abre com o aplicativo padrão do sistema (xdg-open → gio open), em janela própria. */
  app.post('/api/files/open', wrap(async (req, res) => {
    const p = need(req.body?.path); await fs.access(p);
    let last = null;
    for (const [name, args] of [['xdg-open', [p]], ['gio', ['open', p]]]) {
      const bin = findBin(name); if (!bin) continue;
      const r = await startDetached(bin, args);
      if (r.ok) return res.json({ok: true, via: name});
      last = r.error;
    }
    if (last) throw fail(500, 'command_failed', `Não foi possível abrir: ${last}`);
    throw fail(501, 'not_installed', 'Nem xdg-open nem gio foram encontrados (sudo apt install xdg-utils libglib2.0-bin).');
  }));
}
