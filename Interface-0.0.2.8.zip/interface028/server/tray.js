/* Barra de menus / bandeja do sistema (0.0.2.7): leitura rápida do estado de rede, volume, Bluetooth, bateria e perfil de energia
   para os ícones da barra, mais as ações de sessão (bloquear, suspender, reiniciar, desligar, sair).
   Para MUDAR Wi-Fi, Bluetooth, volume ou perfil de energia o painel reutiliza as rotas /api/sys/* (server/system.js).
   Tudo usa execFile (sem shell), timeout curto e tolera a ausência de qualquer ferramenta: cada bloco falha sozinho. */
import fsSync from 'node:fs';
import path from 'node:path';
import {sh, explain, splitTerse, parseWifi} from './system.js';

const T = {timeout: 2500};

/* ---------- Parsers (exportados para teste) ---------- */
/* nmcli -t -f TYPE,STATE,CONNECTION device */
export function parseNmDevices(text) {
  return String(text || '').split('\n').filter(Boolean).map(splitTerse).map(([type, state, ...name]) => ({type, state: String(state || ''), name: name.join(':')}))
    .filter(d => d.type === 'wifi' || d.type === 'ethernet');
}
/* wpctl get-volume → "Volume: 0.45" ou "Volume: 0.45 [MUTED]" */
export function parseWpctlVolume(text) {
  const m = String(text || '').match(/Volume:\s*([\d.]+)/i); if (!m) return null;
  return {volume: Math.round(Number(m[1]) * 100), mute: /\[MUTED\]/i.test(text)};
}
/* amixer sget Master → "Front Left: Playback 40 [62%] [on]" */
export function parseAmixer(text) {
  const p = String(text || '').match(/\[(\d+)%\]/); if (!p) return null;
  return {volume: Number(p[1]), mute: /\[off\]/i.test(text)};
}
/* /sys/class/power_supply/BAT* */
export function readBattery(base = '/sys/class/power_supply') {
  try {
    for (const n of fsSync.readdirSync(base)) {
      const d = path.join(base, n), rd = f => { try { return fsSync.readFileSync(path.join(d, f), 'utf8').trim(); } catch { return ''; } };
      if (rd('type') !== 'Battery' || (rd('scope') && rd('scope') !== 'System')) continue; /* ignora baterias de periféricos (mouse, fone) */
      const percent = Number(rd('capacity')), s = rd('status').toLowerCase();
      return {present: true, percent: Number.isFinite(percent) ? percent : null,
        status: s === 'charging' ? 'charging' : s === 'full' ? 'full' : s === 'discharging' ? 'discharging' : 'unknown'};
    }
  } catch {}
  return {present: false};
}

/* ---------- Leituras ---------- */
async function network() {
  const [dev, radio] = await Promise.all([sh('nmcli', ['-t', '-f', 'TYPE,STATE,CONNECTION', 'device'], T), sh('nmcli', ['radio', 'wifi'], T)]);
  if (dev.ok) {
    const devices = parseNmDevices(dev.stdout), up = d => d.state.startsWith('connected');
    const eth = devices.find(d => d.type === 'ethernet' && up(d)), wifi = devices.find(d => d.type === 'wifi' && up(d));
    const wifiEnabled = radio.ok ? /enabled/i.test(radio.stdout) : null, hasWifi = devices.some(d => d.type === 'wifi');
    const base = {available: true, wifiAvailable: hasWifi, wifiEnabled};
    if (eth) return {...base, state: 'connected', type: 'ethernet', name: eth.name, signal: null};
    if (wifi) {
      const l = await sh('nmcli', ['-t', '-f', 'active,ssid,bssid,signal,security', 'dev', 'wifi', 'list', '--rescan', 'no'], T);
      const cur = l.ok ? parseWifi(l.stdout).find(n => n.active) : null;
      return {...base, state: 'connected', type: 'wifi', name: cur?.ssid || wifi.name, signal: cur?.signal ?? null};
    }
    return {...base, state: devices.some(d => /^connecting/.test(d.state)) ? 'connecting' : 'disconnected', type: null, name: null, signal: null};
  }
  /* sem NetworkManager: usa a rota padrão */
  const r = await sh('ip', ['-j', 'route'], T); if (!r.ok) return {available: false, state: 'unknown'};
  try {
    const d = JSON.parse(r.stdout).find(x => x.dst === 'default');
    return {available: true, wifiAvailable: false, wifiEnabled: null, state: d ? 'connected' : 'disconnected', type: d ? (/^wl/.test(d.dev) ? 'wifi' : 'ethernet') : null, name: d?.dev || null, signal: null};
  } catch { return {available: false, state: 'unknown'}; }
}
async function volume() {
  const wp = await sh('wpctl', ['get-volume', '@DEFAULT_AUDIO_SINK@'], T), a = wp.ok && parseWpctlVolume(wp.stdout);
  if (a) return {available: true, ...a};
  const am = await sh('amixer', ['sget', 'Master'], T), b = am.ok && parseAmixer(am.stdout);
  return b ? {available: true, ...b} : {available: false};
}
async function bluetooth() {
  const r = await sh('bluetoothctl', ['show'], T);
  if (!r.ok || /no default controller/i.test(r.stdout + r.stderr)) return {available: false, powered: false};
  return {available: true, powered: /^\s*Powered:\s*yes/mi.test(r.stdout)};
}
async function profile() {
  const r = await sh('powerprofilesctl', ['get'], T);
  return r.ok ? {available: true, current: r.stdout.trim(), options: ['performance', 'balanced', 'power-saver']} : {available: false};
}

const POWER_ENABLED = () => process.env.INTERFACE_DISABLE_POWER !== '1';
let cached = null, at = 0, inflight = null;
export async function trayStatus() {
  if (cached && Date.now() - at < 1500) return cached;
  inflight ||= (async () => {
    const [n, v, b, p] = await Promise.allSettled([network(), volume(), bluetooth(), profile()]);
    const ok = (r, fb) => r.status === 'fulfilled' ? r.value : fb;
    cached = {network: ok(n, {available: false, state: 'unknown'}), volume: ok(v, {available: false}), bluetooth: ok(b, {available: false, powered: false}),
      profile: ok(p, {available: false}), battery: readBattery(), session: process.env.XDG_SESSION_TYPE || null};
    at = Date.now(); return cached;
  })().finally(() => { inflight = null; });
  return inflight;
}

/* ---------- Sessão ---------- */
export const POWER_ACTIONS = {
  lock: () => [['loginctl', ['lock-session']], ['xdg-screensaver', ['lock']], ['gnome-screensaver-command', ['-l']]],
  suspend: () => [['systemctl', ['suspend']]],
  reboot: () => [['systemctl', ['reboot']]],
  poweroff: () => [['systemctl', ['poweroff']]],
  logout: () => [['gnome-session-quit', ['--logout', '--no-prompt']], ...(process.env.XDG_SESSION_ID ? [['loginctl', ['terminate-session', process.env.XDG_SESSION_ID]]] : [])],
};

export function registerTrayRoutes(app) {
  const wrap = fn => async (req, res) => { try { await fn(req, res); } catch (e) { res.status(500).json({error: 'internal', message: e.message}); } };

  app.get('/api/tray/status', wrap(async (_req, res) => res.json({...await trayStatus(), power: {enabled: POWER_ENABLED()}})));

  app.post('/api/tray/power', wrap(async (req, res) => {
    const action = String(req.body?.action || ''), build = POWER_ACTIONS[action];
    if (!build) return res.status(400).json({error: 'bad_request', message: 'Ação inválida.'});
    if (!POWER_ENABLED()) return res.status(403).json({error: 'disabled', message: 'As ações de energia foram desativadas neste servidor (INTERFACE_DISABLE_POWER=1).'});
    if (action !== 'lock' && req.body?.confirm !== true) return res.status(400).json({error: 'confirm_required', message: 'Confirmação necessária.'});
    let last = null;
    for (const [cmd, args] of build()) {
      const r = await sh(cmd, args, {timeout: 8000});
      if (r.ok) return res.json({ok: true, via: cmd});
      if (!r.missing) last = {...explain(r, 'executar a ação')};
    }
    if (last) return res.status(last.status).json({error: last.error, message: last.message});
    res.status(501).json({error: 'not_installed', message: 'Nenhum comando de sessão disponível (loginctl/systemctl).'});
  }));
}
